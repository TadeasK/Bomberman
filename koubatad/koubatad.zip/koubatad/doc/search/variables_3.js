var searchData=
[
  ['game_5fwindow_5fheight_298',['GAME_WINDOW_HEIGHT',['../classEntity.html#ad7ac13af190987bf57eb130eb4ec5761',1,'Entity::GAME_WINDOW_HEIGHT()'],['../classGameManager.html#aaca5b2e15382d3d8c334b23727dca663',1,'GameManager::GAME_WINDOW_HEIGHT()']]],
  ['game_5fwindow_5fwidth_299',['GAME_WINDOW_WIDTH',['../classEntity.html#ab09992cb7ebcfa0fb5038f4d4da8b15e',1,'Entity::GAME_WINDOW_WIDTH()'],['../classGameManager.html#ade20a5a04e8d37606a27f54a4d0a091f',1,'GameManager::GAME_WINDOW_WIDTH()']]]
];
