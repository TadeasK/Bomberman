var searchData=
[
  ['special_187',['Special',['../classSpecial.html',1,'']]]
];
