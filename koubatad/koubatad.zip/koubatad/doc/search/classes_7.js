var searchData=
[
  ['special_118',['Special',['../classSpecial.html',1,'']]]
];
