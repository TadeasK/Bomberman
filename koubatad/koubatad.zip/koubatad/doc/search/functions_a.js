var searchData=
[
  ['special_190',['Special',['../classSpecial.html#a449253073a1b3206eefd940c85186286',1,'Special']]]
];
