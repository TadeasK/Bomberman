var indexSectionsWithContent =
{
  0: "bcdeghmoprsw~",
  1: "bcegmopsw",
  2: "bcegmopsw",
  3: "bcdeghmoprsw~",
  4: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

