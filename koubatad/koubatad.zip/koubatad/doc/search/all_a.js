var searchData=
[
  ['special_76',['Special',['../classSpecial.html',1,'Special'],['../classSpecial.html#a449253073a1b3206eefd940c85186286',1,'Special::Special()']]],
  ['special_2ecpp_77',['Special.cpp',['../Special_8cpp.html',1,'']]],
  ['special_2ehpp_78',['Special.hpp',['../Special_8hpp.html',1,'']]]
];
