var searchData=
[
  ['initcolors_261',['initColors',['../classMenu.html#af77d0759d2e9ccd86ec0afc2f85149ac',1,'Menu']]],
  ['initncurses_262',['initNcurses',['../classMenu.html#aca4b8911d55b52fc198fac718cb1e183',1,'Menu']]]
];
