#include "ExitDoor.hpp"

ExitDoor::ExitDoor( int x, int y )
: Special (x,y)
{}

void ExitDoor::drawObj() const
{

}

void ExitDoor::giveEffect()
{

}
