#include "BuffThrow.hpp"

BuffThrow::BuffThrow( int x, int y )
: Special (x,y)
{}

void BuffThrow::drawObj() const
{

}

void BuffThrow::giveEffect()
{
    
}