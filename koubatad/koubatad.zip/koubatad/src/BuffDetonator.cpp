#include "BuffDetonator.hpp"

BuffDetonator::BuffDetonator( int x, int y )
: Special (x,y)
{}

void BuffDetonator::drawObj() const
{

}

void BuffDetonator::giveEffect()
{
    
}