#include "BuffBomb.hpp"

BuffBomb::BuffBomb( int x, int y, WINDOW*window )
: Special (x,y,window)
{}

void BuffBomb::drawObj() const
{

}

void BuffBomb::giveEffect()
{
    
}