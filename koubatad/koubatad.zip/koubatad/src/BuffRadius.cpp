#include "BuffRadius.hpp"

BuffRadius::BuffRadius( int x, int y )
: Special (x,y)
{}

void BuffRadius::drawObj() const
{

}

void BuffRadius::giveEffect()
{

}
