#include "Special.hpp"

Special::Special(int x, int y, WINDOW *window)
        : Object(x, y, window) {}

