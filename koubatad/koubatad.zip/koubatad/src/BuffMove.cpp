#include "BuffMove.hpp"

BuffMove::BuffMove( int x, int y )
: Special (x,y)
{}

void BuffMove::drawObj() const
{

}

void BuffMove::giveEffect()
{

}

